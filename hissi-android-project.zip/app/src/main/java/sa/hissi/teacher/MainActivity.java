package sa.hissi.teacher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.webkit.*;
import android.view.*;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
  WebView web;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(18,55,42));
    getWindow().setNavigationBarColor(Color.rgb(18,55,42));
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED)
      requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 100);
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(245,247,244));
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setDatabaseEnabled(true);
    web.getSettings().setAllowFileAccess(false);
    web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    web.setWebViewClient(new WebViewClient());
    setContentView(web);
    web.loadUrl("https://hissi-teacher-schedule.vercel.app");
    createNotificationChannel();
  }
  void createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel("hissi_lessons","تنبيهات الحصص",NotificationManager.IMPORTANCE_HIGH);
      ch.setDescription("تنبيه بداية الحصة ونهايتها");
      ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }
  }
  @Override public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }
}
