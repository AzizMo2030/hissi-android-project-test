package sa.hissi.teacher;

import android.app.*;
import android.content.*;
import android.os.Build;

public class LessonAlarmReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    String title = intent.getStringExtra("title");
    String body = intent.getStringExtra("body");
    Intent open = new Intent(context, MainActivity.class);
    PendingIntent pi = PendingIntent.getActivity(context, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    Notification.Builder b = Build.VERSION.SDK_INT >= 26
      ? new Notification.Builder(context, "hissi_lessons")
      : new Notification.Builder(context);
    Notification n = b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title == null ? "حصصي" : title).setContentText(body == null ? "تذكير بموعد الحصة" : body).setContentIntent(pi).setAutoCancel(true).build();
    ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)System.currentTimeMillis(), n);
  }
}
